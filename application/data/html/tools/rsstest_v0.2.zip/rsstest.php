<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>RSS TEST</title>
</head>
<body>

<?php

class DBConnection {

	private $_handle = null;

	public static function get() {
		static $db = null;
		if ( $db == null ) $db = new DBConnection();
		return $db;
	}
	private function __construct() {
		echo 'start constructor of class DBConnection';
		try {
			echo ' - create DB Connection!!<br>';
		    $this->_handle =& new PDO("mysql:host=mysql9.xserver.jp; dbname=xiaozhe_rsstest", "xiaozhe_rsstest", "bunnta0421");
//		    $this->_handle =& new PDO( $db_sttr );
		} catch(PDOException $e){
			echo $e->getMessage().'<br>';
		    var_dump($e->getMessage());
		}
	}
	public function handle() {
		return $this->_handle;
	}
}

// --------------------------------------------------------------
// class FeedList
// --------------------------------------------------------------
class FeedList {

//	private $debug = 1;

	public static function get( $db ) {
		try {
			$stmt = $db->prepare( "SELECT * FROM rss_feeds" );
			$stmt->execute();
			$result = $stmt->fetchAll();
		} catch ( PDOException $e ){
			var_dump( $e->getMessage() );
		}
		return $result;
	}

	public static function fetch( $db ) {

		$feedlist = FeedList::get( $db );

		for( $n=0; $n<count($feedlist); $n++ ) {
			echo 'last_update = '.$feedlist[$n]['last_update'].'('.strtotime($feedlist[$n]['last_update']).')<br>';

			$last_post_date = Feed::fetch( $db, $feedlist[$n] );
			if( $last_post_date != '' && strtotime( $last_post_date ) > strtotime( $last_update ) ) {
	//			echo 'START FeedList::UPDATE_last_update()';
					$stmt = $db->prepare( "UPDATE `rss_feeds` SET `last_update` = :time WHERE `rss_feed_id` = :rss_feed_id" );
			        $stmt->bindValue(':time', date('Y-m-d H:i:s', strtotime($last_post_date) ) );
			        $stmt->bindValue(':rss_feed_id', $feedlist[$n]['rss_feed_id']);
					$stmt->execute();
	//			echo '　　OK<br>';
			}
		}
	}


/*
	public static function add( $db ) {
		try {
			echo 'START FeedList::insert_db()';
			$stmt = $db->prepare( "INSERT INTO rss_feeds(url, name, last_update) VALUES(:url, :name, :last_update)");
	        $stmt->bindValue(':url', $values['rss_feed_id']);
	        $stmt->bindValue(':name', $values['link']);
	        $stmt->bindValue(':last_update', $values['title']);

			if( $stmt->execute() ) {
				echo '　　OK<br>';
			} else {
				echo '　　NG<br>';
			}
		} catch (PDOException $e){
			var_dump($e->getMessage());
		}
	}
*/

}

// --------------------------------------------------------------
// class Feed
// --------------------------------------------------------------

class Feed {

	public static function get( $db, $id ) {
		try {
//			echo 'SELECT * FROM `rss_articles` WHERE `rss_feed_id` = '.$id;
				$stmt = $db->prepare( "SELECT * FROM `rss_articles` WHERE `rss_feed_id` = :id ORDER BY `post_time`" );
		        $stmt->bindValue(':id', $id);
				$stmt->execute();
				$result = $stmt->fetchAll();
//			echo '   OK<br>';
		} catch ( PDOException $e ){
			var_dump( $e->getMessage() );
		}
		return $result;
	}

	public static function insert_db( $db, $article ) {
		try {
			echo 'START FeedArticle::insert_db()';
				$stmt = $db->prepare("INSERT INTO rss_articles(rss_feed_id, link, title, description, post_time) VALUES(:rss_feed_id, :link, :title, :desc, :post_time)");
		        $stmt->bindValue(':rss_feed_id', $article['rss_feed_id']);
		        $stmt->bindValue(':link', $article['link']);
		        $stmt->bindValue(':title', $article['title']);
		        $stmt->bindValue(':desc', $article['desc']);
		        $stmt->bindValue(':post_time', $article['post_time']);
				$stmt->execute();
			echo '　　OK<br>';
		} catch (PDOException $e){
			var_dump($e->getMessage());
		}
		return true;
	}

	public static function fetch( $db, $feed ) {

		$rss_feed_id = $feed['rss_feed_id'];
		$url = $feed['url'];
		$last_update = $feed['last_update'];
		echo '$rss_fetch_url = '.$url.'<br>';

		$rss = simplexml_load_file( $url );

		if( !empty( $rss ) || $rss <> '' ) {
			$channel = $rss->channel;
			$last_post_date = '';

			foreach ($channel->item as $item) {
				$article = null;
				$article['rss_feed_id']	= $rss_feed_id;
				$article['link']	= mb_convert_encoding( $item->link, "UTF-8", "auto" );
				$article['title']	= mb_convert_encoding( $item->title, "UTF-8", "auto" );
				$article['desc']	= mb_convert_encoding( $item->description, "UTF-8", "auto" );
				$article['post_time']	= get_formatted_time($item->pubDate);

				if( $debug == 1 ) {
					echo '=====================================================<br>';
					echo '$article[\'rss_feed_id\']	= '.$rss_feed_id.'<br>';
					echo '$article[\'link\']	= '.$item->link.'<br>';
					echo '$article[\'title\']	= '.$item->title.'<br>';
					echo '$article[\'date\']	= '.$item->pubDate.'<br>';
					echo '$article[\'desc\']	= '.$item->description.'<br>';
					echo '$article[\'post_time\']	= '.get_formatted_time($item->pubDate).'<br>';
					echo '-----------------------------------------------------<br>';
					echo 'posted_time = '.$article['post_time'].'('.strtotime($article['post_time']).')<br>';
				}

				if( strtotime($last_update) < strtotime($article['post_time']) ) {
					if( Feed::insert_db( $db, $article ) ) {
						if( $last_post_date == '' || strtotime($last_post_date) < strtotime($article['post_time']) ) {
							$last_post_date = $article['post_time'];
						}
					} else {
						echo 'DB Article の insert に失敗しました。';
					}
				} else {
					echo 'doesn\'t insert_db()<br>';
				}
			}
			return $last_post_date;

		} else {
			echo 'RSS の取得に失敗しました。<br>';
			echo 'RSS URL = '.$url.'<br>';
			return;
		}
	}
}


// --------------------------------------------------------------
// functions()
// --------------------------------------------------------------
function get_formatted_time($target) {

	$debug	= 0;
	$date	= array(
		"Jan"=>1
		, "Feb"=>2
		, "Mar"=>3
		, "Apr"=>4
		, "May"=>5
		, "Jun"=>6
		, "Jul"=>7
		, "Aug"=>8
		, "Sep"=>9
		, "Oct"=>10
		, "Nov"=>11
		, "Dec"=>12
	);

	$array = explode(' ', $target);
	$time = explode(':', $array[4]);

	$year	= $array[3];
	$month	= $date[$array[2]];
	$day	= $array[1];
	$hour	= $time[0];
	$minute	= $time[1];
	$sec	= $time[2];

	if( $debug == 1 ) {
		for( $n=0; $n<count($array); $n++ ) {
			echo '$array['.$n.']= '.$array[$n].'<br>';
		}
		echo '年：'.$year.'<br>';
		echo '月：'.$month.'<br>';
		echo '日：'.$day.'<br>';
		echo '時：'.$hour.'<br>';
		echo '分：'.$minute.'<br>';
		echo '秒：'.$sec.'<br>';
		echo 'unixtime = '.date('Y-m-d H:i:s', mktime( $hour, $minute, $sec, $month, $day, $year ) ).'<br>';
		echo 'formatted_time = '.date('Y-m-d H:i:s', mktime( $hour, $minute, $sec, $month, $day, $year ) ).'<br>';
	}

	return date('Y-m-d H:i:s', mktime( $hour, $minute, $sec, $month, $day, $year ) );
}

/*
$db = DBConnection::get()->handle();
FeedList::fetch($db);
$db = null;
*/

?>



<h3>DB から取得して表示</h3>
<?
$db = DBConnection::get()->handle();
$feedlist = FeedList::get( $db );
foreach($feedlist as $feed) {
	$feed_name = $feed['name'];
	$articles = Feed::get( $db, $feed['rss_feed_id'] );
	echo '<h3>'.$feed_name.'</h3>';
	echo '<p>（最終更新日：'.date( 'Y年m月d日 H時i分', strtotime($feed['last_update']) ).')</p>';
	echo '<ol>';
	foreach( $articles as $article ) {
		$link		= $article['link'];
		$title		= $article['title'];
		$post_time	= $article['post_time'];
		$desc		= $article['desc'];
		echo '<li><a href="'.$link.'" title="'.$title.'">'.$title.'</a>'.$post_time.'<p>'.$desc.'</p></li>'."\n";
	}
	echo '</ol>';
}
$db = null;

?>


<br />
<hr size="1">
<br />



<h3>直接 RSS から取得して直接表示</h3>

<?php

$url = "http://feeds.feedburner.com/hatena/b/hotentry";
$url = "http://rss.dailynews.yahoo.co.jp/fc/rss.xml";

$xmlstr = file_get_contents($url);
mb_convert_encoding($xmlstr,"UTF-8");
$rss = simplexml_load_string($xmlstr);

//$rss = simplexml_load_file( $url );
//var_dump($rss);


$channel = $rss->channel;
$feed_title = $channel->title;
echo '<h3>'.$feed_title.'</h3>';
echo '<ol>';
	foreach ($channel->item as $item) {
		$link = $item->link;
		$title = $item->title;
	//	$title = mb_convert_encoding( $item->title, "UTF-8" );
	//	$title = mb_convert_encoding( $item->title, "UTF-8", "shift-jis" );
	//	$title = mb_convert_encoding( $item->title, "SJIS", "UTF-8" );
	//	$title = mb_convert_encoding( $item->title, "UTF-8", "SJIS" );
	//	$title = mb_convert_encoding( $item->title, "UTF-8", "sjis-win" );
	//	$title = mb_convert_encoding( $item->title, "UTF-8", "eucjp-win" );
	//	$title = mb_convert_encoding( $item->title, "UTF-8", "EUC-JP" );
	//	$title = mb_convert_encoding( $item->title, "UTF-8", "auto" );

		$date = $item->pubDate;
		$desc =$item->description;
		echo "<li><a href=\"$link\" title=\"$title\">$title</a>$date</li>\n";
	}

	foreach ($rss->item as $item) {
		//$dc = $item->children('http://purl.org/dc/elements/1.1/');
		$link = $item->link;
		$title = $item->title;
		$date = $dc->date;
		$desc =$item->description;
		echo "<li><a href=\"$link\" title=\"$title\">$title</a>$date<p>$desc</p></li>\n";
	}
echo '</ol>';
?>



</body>
</html>
